#include "align.h"
#include <string>

using std::string;
using std::cout;
using std::endl;
using std::make_tuple;
using std::get;
Image align(Image srcImage, bool isPostprocessing, std::string postprocessingType, double fraction, bool isMirror, 
            bool isInterp, bool isSubpixel, double subScale)
{
	int n=srcImage.n_rows,m=srcImage.n_cols,i=0,j=0,t=0,r=0;
	int x=0,y=0;
	double min=0,mse=0,a=0,b=0,k=0,l=0;
	Image img1(n/3,m),img2(n/3,m),img3(n/3,m),img(n/3,m);
	
	for (i=0;i<n/3;i++)
		for(j=0;j<m;j++)
			min+=(get<0>(srcImage(i,j))-get<0>(srcImage(i+n/3,j)))*(get<0>(srcImage(i,j))-get<0>(srcImage(i+n/3,j)));
	min=min/((n/3)*m);
	
	for(i=-15;i<16;i++){
		for(j=-15;j<16;j++){
			mse=0;
			if (i>=0) {a=0;b=n/3-i;}
			if (i<0)  {a=-i;b=n/3;}
			if(j>=0)  {l=0;k=m-j;}
			if (j<0)  {l=-j;k=m;}
			for (t=a+n/60;t<b-n/60;t++)
				for (r=l;r<k;r++)
					mse+=(get<0>(srcImage(t,r))-get<0>(srcImage(t+n/3+i,r+j)))*(get<0>(srcImage(t,r))-get<0>(srcImage(t+n/3+i,r+j)));
			mse=mse/((b-a)*(k-l));		
			
		    if (min>mse){
				y=i;
				x=j;
				min=mse;
				}
			}
		}
		mse=min;

	for (i=0;i<n/3;i++)
		for(j=0;j<m;j++)
			img1(i,j)=make_tuple(get<0>(srcImage(i,j)),get<1>(srcImage(i,j)),get<2>(srcImage(i,j)));
    for(i=0;i<n/3;i++)
		for(j=0;j<m;j++)
			img2(i,j)=make_tuple(get<0>(srcImage(i+n/3,j)),get<1>(srcImage(i+n/3,j)),get<2>(srcImage(i+n/3,j)));
	 
	 int y1=0,y2=0,x1=0,x2=0;
	 if (y>0) {y1=0;y2=n/3-y;}
	 if (y<0) {y1=abs(y);y2=n/3;}
	 if (x>0) {x1=0;x2=m-x;}
	 if (x<0) {x1=abs(x);x2=m;}
	 
				for (i=y1;i<y2;i++)
					for (j=x1;j<x2;j++)
						img(i,j)=make_tuple(get<0>(img2(i+y,j)),get<1>(img2(i+y,j)),get<2>(img2(i+y,j)));

	for(i=0;i<n/3;i++)
	   for(j=0;j<m;j++)
		 img1(i,j)=make_tuple(get<0>(img1(i,j)),get<1>(img(i,j)),get<2>(img1(i,j)));

	
	for (i=0;i<n/3;i++)
		for(j=0;j<m;j++)
			min+=(get<2>(img1(i,j))-get<2>(srcImage(i+(2*n)/3,j)))*(get<2>(img1(i,j))-get<2>(srcImage(i+(2*n)/3,j)));
	 min=min/((n/3)*m);
	for(i=-15;i<16;i++){
		for(j=-15;j<16;j++){
			mse=0;
			if (i>=0) {a=0;b=n/3-i;}
			if (i<0)  {a=-i;b=n/3;}
			if(j>=0)  {l=0;k=m-j;}
			if (j<0)  {l=-j;k=m;}
			for (t=a+n/60;t<b-n/60;t++)
				for (r=l;r<k;r++)
					mse+=(get<2>(img1(t,r))-get<2>(srcImage(t+(2*n)/3+i,r+j)))*(get<2>(img1(t,r))-get<2>(srcImage(t+(2*n)/3+i,r+j)));
			mse=mse/((b-a)*(k-l));		
			
		    if (min>mse){
				y=i;
				x=j;
				min=mse;
				}
			}
		}
		mse=min;	
		
    for(i=0;i<n/3;i++)
		for(j=0;j<m;j++)
			img3(i,j)=make_tuple(get<0>(srcImage(i+(2*n)/3,j)),get<1>(srcImage(i+(2*n)/3,j)),get<2>(srcImage(i+(2*n)/3,j)));
	 
	 
	 if (y>0) {y1=0;y2=n/3-y;}
	 if (y<0) {y1=abs(y);y2=n/3;}
	 if (x>0) {x1=0;x2=m-x;}
	 if (x<0) {x1=abs(x);x2=m;}
	 
				for (i=y1;i<y2;i++)
					for (j=x1;j<x2;j++)
						img(i,j)=make_tuple(get<0>(img3(i+y,j)),get<1>(img3(i+y,j)),get<2>(img3(i+y,j)));
	for(i=0;i<n/3;i++)
	   for(j=0;j<m;j++)
		img1(i,j)=make_tuple(get<0>(img(i,j)),get<1>(img1(i,j)),get<2>(img1(i,j)));

	if (isPostprocessing==true){
		if (postprocessingType=="--gray-world")
			gray_world(img1);
		if (postprocessingType=="--unsharp")
			unsharp(img1);
		}
    return img1;
}

Image sobel_x(Image src_image) {
    Matrix<double> kernel = {{-1, 0, 1},
                             {-2, 0, 2},
                             {-1, 0, 1}};
    return custom(src_image, kernel);
}

Image sobel_y(Image src_image) {
    Matrix<double> kernel = {{ 1,  2,  1},
                             { 0,  0,  0},
                             {-1, -2, -1}};
    return custom(src_image, kernel);
}

Image unsharp(Image src_image) {
	int n=src_image.n_rows,m=src_image.n_cols;
	int i=0,j=0,k=0,l=0,r=0,g=0,b=0,y1=0,y2=0,x1=0,x2=0;
	double kernel[3][3]={{-1/6.,-2/3.,-1/6.},{-2/3.,13/3.,-2/3.},{-1/6.,-2/3.,-1/6.}};
	Image out(n,m);
		
		for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			double RS=0,GS=0,BS=0,S=0;
			if (i==0) {y1=1;y2=2;}
			if (j==0) {x1=1;x2=2;}
			if ((i>0)&&(i<n)) {y1=0;y2=2;}
			if (i==n) {y1=0;y2=1;}
			if ((j>0)&&(j<m)) {x1=0;x2=2;}
			if (j==m) {x1=0;x2=1;}
			for (k=y1;k<=y2;k++){
				for (l=x1;l<=x2;l++){
					r=get<0>(src_image(i,j));
					g=get<1>(src_image(i,j));
					b=get<2>(src_image(i,j));
					double kernelvalue=kernel[k][l];
					RS+=r*kernelvalue;
					GS+=g*kernelvalue;
					BS+=b*kernelvalue;
					S+=kernelvalue;
					}
				}
				if (S<=0) S=1;
				RS/=S; GS/=S; BS/=S;
				if (RS<0) RS=0;
				if (RS>255) RS=255;
				if (GS<0) GS=0;
				if (GS>255) GS=255;
				if (BS<0) BS=0;
				if (BS>255) BS=255;
					
		 out(i,j)=make_tuple(RS,GS,BS);
			
			}
	}
    return out;
}

Image gray_world(Image src_image) {
	int n=src_image.n_rows,m=src_image.n_cols;
	int i=0,j=0,s=0,l=0;
	double R=0,G=0,B=0,AVG=0;
	
	for(i=0;i<n;i++)
		for(j=0;j<m;j++){
			s+=get<0>(src_image(i,j));
			l++;
		}
			R=s/l;
			s=0;
			l=0;
	for(i=0;i<n;i++)
		for(j=0;j<m;j++){
			s+=get<1>(src_image(i,j));
			l++;
		}
			G=s/l;
			s=0;
			l=0;
	for(i=0;i<n;i++)
		for(j=0;j<m;j++){
			s+=get<2>(src_image(i,j));
			l++;
		}
			B=s/l;
			l=0;
			s=0;
	AVG=(R+G+B)/3;
	cout<<AVG<<' '<<R<<' '<<G<<' '<<B<<endl;
	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
			src_image(i,j)=make_tuple(get<0>(src_image(i,j))*(AVG/R),get<1>(src_image(i,j))*(AVG/G),get<2>(src_image(i,j))*(AVG/B));
    return src_image;
}

Image resize(Image src_image, double scale) {
    return src_image;
}

Image custom(Image src_image, Matrix<double> kernel) {
    // Function custom is useful for making concrete linear filtrations
    // like gaussian or sobel. So, we assume that you implement custom
    // and then implement other filtrations using this function.
    // sobel_x and sobel_y are given as an example.
    return src_image;
}

Image autocontrast(Image src_image, double fraction) {
    return src_image;
}

Image gaussian(Image src_image, double sigma, int radius)  {
    return src_image;
}

Image gaussian_separable(Image src_image, double sigma, int radius) {
    return src_image;
}

Image median(Image src_image, int radius) {
    return src_image;
}

Image median_linear(Image src_image, int radius) {
    return src_image;
}

Image median_const(Image src_image, int radius) {
    return src_image;
}

Image canny(Image src_image, int threshold1, int threshold2) {
    return src_image;
}
